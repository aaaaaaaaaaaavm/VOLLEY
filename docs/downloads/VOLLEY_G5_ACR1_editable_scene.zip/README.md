# VOLLEY G5 ACR1 — CAD-derived scientific views

Four orthographic views are provided as 2800 × 2100 PNG and quality-95 JPEG files in `renders/`:

| Figure | Frozen CAD state | Purpose |
| --- | --- | --- |
| `01_assembly_isometric` | home | Complete assembly in a true isometric projection; all 387 native CAD objects are present. |
| `02_handoff_pallet_locks` | handoff | Close view of the captured pallet, its bayonet locks, feet, and outboard lift grips. Storage banks, host mounting ladder, and the connected fixed lift frame are explicitly hidden for access. All 387 objects remain in the editable scene; the 219 omitted objects are listed by name in provenance. |
| `03_captured_source_level` | captured | Source level 5 transfer: payload and pallet held at floor Z830 by the lift. |
| `04_clear_docked` | clear | Payload floor Z46 and retained carrier pallet below the raised custody frame at floor Z190. Camera framing crops upper levels and distant track; no CAD objects are hidden. |

The blue solids are nominal 3U payload envelopes from the CAD, not fabricated spacecraft panels or flight imagery. All hardware surfaces come directly from the frozen native model, including its explicitly declared reference actuator envelopes. White caption margins, text, leader lines, and scale bars belong to separate display-only annotation collections. Scale bars measure length in the orthographic image plane.

## Provenance

`export_native_meshes.py` reads the final FCStd captures without saving or changing them. It verifies their recorded hashes against `cad/release/FINAL_CAD_MANIFEST.json` and the independently passing STEP readback summary before tessellation. Every selected native file is already independently STEP-matched; this workflow does not rerun CAD acceptance tests.

The visualization meshes use FreeCAD `MeshPart.meshFromShape`, with 0.3 mm maximum linear deflection, 0.15 rad angular deflection, and no relative tolerance. Vertex coordinates are converted from native millimetres to metres. These meshes are for visualization, not structural or contact analysis.

`MESH_PROVENANCE.json`, `VIEW_PROVENANCE.json`, and each `renders/*_provenance.json` record native/STEP hashes, all six frozen source hashes, mesh hashes, camera settings, material styling, omission lists, exact leader target coordinates, and final image hashes. `VISUALS_MANIFEST.json` lists the distributable artifacts.

## Editable source and reproduction

`VOLLEY_G5_ACR1_scientific_views.blend` contains all four scenes, their cameras, geometry, material colors, editable annotations, and a packed annotation font. Select the named scene to inspect or render it. Blender 4.3.2 Workbench is the recorded renderer; the views use studio shading with shadows disabled and a white background.

The included mesh JSON files and `render_cad_views.py` reproduce the scenes without requiring an external CAD import:

```sh
blender -b -t 4 -P render_cad_views.py
```

To regenerate meshes in the original managed environment while preserving the sibling `cad/` and `verification/` directories:

```sh
PYTHONPATH=/usr/lib/freecad-python3/lib /usr/bin/python3 export_native_meshes.py
```

PNG is lossless; JPEG is an alternate delivery format. At 180 mm image width, the pixel dimensions provide approximately 395 pixels per inch. The original native geometry, source files, and completed mechanical tests remain unchanged.
