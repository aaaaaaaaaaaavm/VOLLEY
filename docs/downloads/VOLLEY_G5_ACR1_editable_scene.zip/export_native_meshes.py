"""Read-only tessellation of the frozen, independently STEP-matched native CAD."""
from pathlib import Path
import json,hashlib,time
import FreeCAD as App
import MeshPart
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent;CAD=ROOT/'cad'/'release';OUT=HERE/'meshes';OUT.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((CAD/'FINAL_CAD_MANIFEST.json').read_text())
readback=ROOT/'verification'/'FINAL_STEP_READBACK_SUMMARY.json';verified=json.loads(readback.read_text())
assert verified['all_eight_states_pass']
records=[]
for state in ['home','handoff','captured','clear']:
 start=time.perf_counter();entry=next(x for x in manifest['states']if x['state']==state)
 native=CAD/('VOLLEY_G5_ACR1_'+state+'.FCStd');step=CAD/('VOLLEY_G5_ACR1_'+state+'.step');bom=CAD/('VOLLEY_G5_ACR1_'+state+'.json')
 assert sha(native)==entry['files'][native.name]['sha256']
 assert sha(step)==entry['files'][step.name]['sha256']
 match=next(x for x in verified['states']if x['state']==state);assert match['source_identity']['native_FCStd_sha256']==sha(native)and match['source_identity']['step_sha256']==sha(step)
 doc=App.openDocument(str(native));objects=[]
 for ob in doc.Objects:
  if not hasattr(ob,'Shape')or ob.Shape.isNull():continue
  mesh=MeshPart.meshFromShape(Shape=ob.Shape,LinearDeflection=.3,AngularDeflection=.15,Relative=False)
  vertices,triangles=mesh.Topology
  objects.append({'name':ob.Label,'material':ob.Material,'subsystem':ob.Subsystem,'vertices_m':[[round(v.x*.001,9),round(v.y*.001,9),round(v.z*.001,9)]for v in vertices],'triangles':[list(t)for t in triangles]})
 App.closeDocument(doc.Name)
 provenance={'state':state,'native_path':str(native),'native_sha256':sha(native),'step_path':str(step),'step_sha256':sha(step),'bom_path':str(bom),'bom_sha256':sha(bom),'source_sha256':manifest['source_sha256'],'independent_step_readback':{'path':str(readback),'sha256':sha(readback),'pass':match['pass']},'tessellation':{'tool':'FreeCAD MeshPart.meshFromShape','linear_deflection_mm':.3,'angular_deflection_rad':.15,'relative':False,'units':'meters;native coordinates divided by1000','purpose':'Visualization only;not analysis mesh'},'object_count':len(objects),'triangle_count':sum(len(q['triangles'])for q in objects)}
 output=OUT/(state+'.json');output.write_text(json.dumps({'provenance':provenance,'objects':objects},separators=(',',':'))+'\n')
 records.append({'state':state,'mesh_file':str(output),'mesh_sha256':sha(output),**provenance});print('TESSELLATED',state,len(objects),provenance['triangle_count'],time.perf_counter()-start,flush=True)
(HERE/'MESH_PROVENANCE.json').write_text(json.dumps({'configuration_id':manifest['configuration_id'],'cad_manifest_path':str(CAD/'FINAL_CAD_MANIFEST.json'),'cad_manifest_sha256':sha(CAD/'FINAL_CAD_MANIFEST.json'),'states':records},indent=2)+'\n')
