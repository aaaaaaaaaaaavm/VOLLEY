# Lunar-first local review package

Adityavardhan Mishra · 17 September 2026

Open `VOLLEY/docs/lunar.html` in a browser from the extracted package. It uses
local assets and scripts. Start with the assembly selector, then the lunar orbit
controls. Real browser/WebGL/mobile behavior still requires verification.
Static PNG/SVG views remain available under `VOLLEY/docs/assets/lunar`.

Four concept STEP and STL assemblies are under `VOLLEY/cad/lunar_concept`.
Import STEP into Fusion in mm. The component tree is a concept envelope layout,
not native parametric features or released manufacturing geometry. The MC-L2
working stroke is 80 mm. All 21 detailed component groups remain in the CAD handoff.

Read `VOLLEY/docs/LUNAR_VISUAL_REVIEW.md` for computed results, assumptions,
limitations and the reproduction commands. C0-S2 source, result, criteria,
retained serialization failure, CAD generator and figure generators are included.
BOLLEY's local website update and field-visual source/data are also included.

This is a focused review package, not the complete repository history or a
recovery of the earlier missing archive. Other historical documentation is
included for reading; some links to repository material outside this package
need the full working copy. Nothing has been pushed or deployed.

Open engineering: actual lunar lifetime/coverage, ephemeris-targeted encounter,
finite burns, full release campaign/uncertainty, both end-of-life cases, current
cell component selection/catcher/installed accounting and BOLLEY magnetic redesign.
