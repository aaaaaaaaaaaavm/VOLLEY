# Fresh wire-resolved field of the reconciled geometry

Adityavardhan Mishra · 17 September 2026

I test the actual twelve bare-wire transverse sections on A6j-R2: 0.25 mm winding lift and 2 mm yoke/outer-leg rise, retaining the 4 mm haunch. This is a fresh nonlinear field calculation, not a transferred A6h verdict.

| Placement | Mean field, fine (T) | Numerical checks | Failed physical/model bands |
|---|---:|---|---|
| lower | 0.751992 | pass | slot_flux_balance |
| upper | 0.744987 | pass | stationary_core_field |

Disposition: **REJECT_POWERED_COUPON_PROMOTION**.

The current-source integral, convergence and physical bands remain distinct. A geometry clearance pass cannot repair magnetic performance. No selected powered coupon, end-lead geometry, transient force/current, hot switching, protection or thermal validation follows from this transverse RMS-equivalent magnetostatic model.

[Criteria](../validation/A6k_reconciled_wire_field.md) · [Full resolved inputs and mesh results](../analysis/results/reconciled_wire_field.json) · [Geometry](CORE_WINDING_RECONCILIATION.md)
